///////////////////////////////////////////////////
/                                                 /
/ XXXXX X     X   X xxxxx xxxx                    /
/ X     X      X X  x     x   x                   /
/ XXX   X       X   xxx   xxxx                    /
/ X     X      X X  x     x  x                    /
/ X     XXXXX X   X xxxxx x   x     SOKET SERVER  /
/                                                 /
///////////////////////////////////////////////////

- Open Terminal

- surf the folders to rach the folder named ""

- Run java -jar fms.jar

- Run FLxER4streamsOut

Commands

q	close the application
info	open connection list
ch	channels list